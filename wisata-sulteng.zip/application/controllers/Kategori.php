<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kategori extends CI_Controller
{

  public function __construct()
  {
    parent::__construct();
  }

  public function alam()
  {
    $data['title'] = 'Wisata Alam';
    $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
    $data['alam'] = $this->kategori_model->data_alam()->result();

    $data['terbaru'] = $this->kategori_model->data_terbaru()->row();
    $data['populer'] = $this->kategori_model->data_populer()->row();

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar', $data);
    $this->load->view('templates/topbar', $data);
    $this->load->view('Kategori/alam', $data);
    $this->load->view('templates/footer');
  }


  public function kuliner()
  {
    $data['title'] = 'Wisata Kuliner';
    $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
    $data['kuliner'] = $this->kategori_model->data_kuliner()->result();

    $data['terbaru'] = $this->kategori_model->data_terbaru()->row();
    $data['populer'] = $this->kategori_model->data_populer()->row();

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar', $data);
    $this->load->view('templates/topbar', $data);
    $this->load->view('Kategori/kuliner', $data);
    $this->load->view('templates/footer');
  }


  public function religi()
  {
    $data['title'] = 'Wisata Religi';
    $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
    $data['religi'] = $this->kategori_model->data_religi()->result();

    $data['terbaru'] = $this->kategori_model->data_terbaru()->row();
    $data['populer'] = $this->kategori_model->data_populer()->row();

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar', $data);
    $this->load->view('templates/topbar', $data);
    $this->load->view('Kategori/religi', $data);
    $this->load->view('templates/footer');
  }


  public function budaya()
  {
    $data['title'] = 'Wisata Budaya';
    $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
    $data['budaya'] = $this->kategori_model->data_budaya()->result();

    $data['terbaru'] = $this->kategori_model->data_terbaru()->row();
    $data['populer'] = $this->kategori_model->data_populer()->row();

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar', $data);
    $this->load->view('templates/topbar', $data);
    $this->load->view('Kategori/budaya', $data);
    $this->load->view('templates/footer');
  }



  public function sejarah()
  {
    $data['title'] = 'Wisata Sejarah';
    $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
    $data['sejarah'] = $this->kategori_model->data_sejarah()->result();

    $data['terbaru'] = $this->kategori_model->data_terbaru()->row();
    $data['populer'] = $this->kategori_model->data_populer()->row();

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar', $data);
    $this->load->view('templates/topbar', $data);
    $this->load->view('Kategori/sejarah', $data);
    $this->load->view('templates/footer');
  }


  public function detail_wisata($id)
  {
    $data['title'] = 'Detail Wisata';
    $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
    $data['detail'] = $this->kategori_model->data_detail($id);

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar', $data);
    $this->load->view('templates/topbar', $data);
    $this->load->view('Kategori/detail_wisata', $data);
    $this->load->view('templates/footer');
  }





}

  /* End of file Kategori.php */
