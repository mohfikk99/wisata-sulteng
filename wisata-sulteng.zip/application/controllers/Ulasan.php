<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ulasan extends CI_Controller
{


  public function index()
  {
    $data['title'] = 'Halaman Utama';
    $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

    $data['map'] = $this->db->get('user_wisata')->result_array();

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar', $data);
    $this->load->view('templates/topbar', $data);
    $this->load->view('ulasan/index', $data);
    $this->load->view('templates/footer');

 }

 public function tentang_kami()
 {
   $data['title'] = 'Tentang Kami';
   $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

   $this->load->view('templates/header', $data);
   $this->load->view('templates/sidebar', $data);
   $this->load->view('templates/topbar', $data);
   $this->load->view('ulasan/tentang_kami', $data);
   $this->load->view('templates/footer');
 }

 public function gelery()
 {
   $data['title'] = 'Geleri';
   $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

   $data['wisata'] = $this->db->get('user_wisata')->result_array();

   $this->load->view('templates/header', $data);
   $this->load->view('templates/sidebar', $data);
   $this->load->view('templates/topbar', $data);
   $this->load->view('ulasan/gelery', $data);
   $this->load->view('templates/footer');
 }



 }
