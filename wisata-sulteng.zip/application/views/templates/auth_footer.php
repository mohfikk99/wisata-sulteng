<script src="<?= base_url('assets/'); ?>jquery/jquery.min.js"></script>
<script src="<?= base_url('assets/'); ?>js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url('assets/'); ?>jquery-easing/jquery.easing.min.js"></script>
<script src="<?= base_url('assets/'); ?>js/desain-utama.min.js"></script>

</body>

</html>
