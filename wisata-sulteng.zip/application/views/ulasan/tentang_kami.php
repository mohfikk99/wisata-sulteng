<div class="container-fluid">

  <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

  <div class="card" style="background-color:#990900;">
    <div class="card-body">
      <div class="row">
        <div class="col-md-4">
          <img src="<?= base_url('assets/img/logo.jpg'); ?>" style="width:100%; border: 5px solid white;">
        </div>
        <div class="col-md-8">
          <p>SULAWESI TENGAH berada di kawasan Indonesia timur, yang menyimpan keindahan tersembunyi di garis Khatulistiwa. <br>
            Kami memberikan informasi Pariwsiata dan Kebudyaan yang anda butuhkan untuk menambah daftar perjalanan wisata anda. <br>
            Nikmatilah keindahan khatulistiwa yang tersaji secara indah, akurat, dan terpercaya yang akan menemani
            perjalanan dan petualangan anda, dimanapun kapanpun </p>
          <table class="table" style="color:white;">
            <tr>

              <td>Email :</td>
              <td> wisatasulteng077gmail.com</td>
            </tr>
            <tr>
              
              <td>Alamat : </td>
              <td>Kota Palu, Sulawesi Tengah</td>
            </tr>
          </table>
        </div>
      </div>

    </div>
  </div>

</div>
</div>
